<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<main> 
        <div class="egy">
            <h3><video width="100%" height="100%" controls>
           <source src="video/video3.mp4" type="video/mp4">
        </video>
          </h3>
        </div>
        <div class="egy">
            <h3><video width="100%" height="100%" controls>
           <source src="video/video2.mp4" type="video/mp4">
        </video>
          </h3>
        </div>
        <div class="egy">
            <h3><video width="100%" height="100%" controls>
           <source src="video/video1.mp4" type="video/mp4">
        </video>
          </h3>
        </div>
        <div class="egy">
        <a href="rolunk.html"><img src="img/pre-logo.jpg" alt="Pécsi Rózsa Egyesület logója"></a>
        </div>
        <div>
            <h3>Kedves Pécsi Rózsa Tag!</h3>
            <p> Üdvözlünk a Pécsi Rózsa Extra oldalon!
        Hamarosan feltöltésre kerülnek oktató videóink előzetesei is. Oktató videóink megvásárlhatók lesznek regisztrált tagjaink számára.</p> </div>
        <div><h3>Készülőben az alábbi videóink:</h3>
            <ul>
                <li>Török cigánytánc alapok 1.</li>
                <li>Török cigánytánc alapok 2.</li>
                <li>Fátyoltechnika</li>
                <li>Török ritmusok</li>
            </ul>
         </div>
</main>
</body>
</html>